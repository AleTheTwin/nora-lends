source activate tensorflow_env
pip install spyne
pip install lxml
python soap_service.py